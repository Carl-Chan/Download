var commondb = require('../includes/commondb');


//Dirty Code to query 2 users only.
exports.IfBothUserExist = function UserExist(values, callback) {

  
  var valuestostring = ""

  for (x = 0; x < values.length; x++) {
    if (x > 0) {
      valuestostring += ","
    }
    valuestostring += "'" + values[x] + "'"
  }
  var sql = " select uid from user where uid in ("+valuestostring+")"
  console.log(sql)

  commondb.ExecuteQuerySQL(sql, [], function (result) {
    console.log(result);
    return callback(result)
  })

}

exports.IfUserExist = function UserExist(values, callback) {
  var sql = " select 1 from user where uid = ? ";
  commondb.ExecuteQuerySQL(sql, values, function (result) {
    return callback(result)
  })
}

return module.exports;