var commondb = require('../includes/commondb');

exports.GetInviteRecord = function GetInviteRecord(uid,callback) {
    var sql = " select * from invite,invite_status_list,user where invite.`status` = invite_status_list.`id` AND user.`uid` = invite.uid AND invite.uid = ?"
    var values = [uid]
    commondb.ExecuteQuerySQL(sql,values,function(result){
      return callback(result)
    })
}

exports.SetInvitedUserRegistered = function SetInviteRegistered(uid, inviteduid,callback) {

    //DIRTY CODE : Check if Existing Record Exist SQL nd Parameters
    var validsql = "select 1 from invite where uid = ? AND inviteduid = ?";
    var validvalues = [uid, inviteduid]

    //Insert Invitation Recrod SQL and Parameters 
    var sql = "insert into invite (uid,inviteduid,credit,status) values (?,?,?,1)"
    var credit = 10 //Get Credit from Config.
    var values = [uid, inviteduid,credit]

    //Check If Invitation Record Exist
    commondb.ExecuteQuerySQL(validsql,validvalues,function(result){
      if(result.length == 0)
      {
        //No Exist Record Found, Do Insert
        console.log('Start to Insert Register Record')
        commondb.ExecuteInsertSQL(sql,values,function(result){
          if(result)
          {
            return callback("Resgiter Successful with Ref ID")
          }else
          {
            return callback('Cannot Insert, please contact administrator')
          }
        })
      }else{
        return callback('Invitation Record Already Exist')
      }
    })
}

exports.SetInviteFirstGamed = function SetInviteFirstGamed(inviteduid,callback) {

  try{
    console.log(inviteduid)

    var checksql = "select 1 from invite where inviteduid = ? AND status = 2"
    var checkvalue = [inviteduid]

    var udpatesql = "update invite set status = 2 where inviteduid = ? order by created asc limit 1";
    var updatevalues = [inviteduid]

    commondb.ExecuteQuerySQL(checksql,checkvalue,function(result){

        if(result.length==0)
        {
            commondb.ExecuteUpdateSQL(udpatesql,updatevalues,function(result){
               return callback(result);
            })
        }
        else{
          return callback('User Got Credit Already')
        }
    })
  }catch(err)
  {
    console.log(err.message);
    next();
  }
}


return module.exports;