'use strict';
const mariadb = require('mariadb');
const pool = mariadb.createPool({
    host: '172.105.227.107',
    user: 'administrator',
    password: 'password',
    connectionLimit: 5,
    database: 'plair',
});

//Insert SQL Query @return insert id.
exports.ExecuteInsertSQL = function ExecuteInsertSQL(sql,values,callback) 
{
  console.log('ExecuteInsertSQL')
    pool.getConnection().then(conn => {
        conn.query(sql,values)
          .then((res) => {
              conn.end();
              return callback(res.insertId)
          })
          .catch(err => {
            console.log(err.message);
            conn.end();
          })
      })
}

exports.ExecuteQuerySQL = function ExecuteQuerySQL(sql,values,callback) 
{
  console.log('ExecuteQuerySQL')
    pool.getConnection().then(conn => {
        conn.query(sql,values)
          .then((res) => {
              conn.end();
              return callback(res);
          })
          .catch(err => {
            console.log(err.message);
            conn.end();
          })
      })
}

exports.ExecuteUpdateSQL = function ExecuteUpdateSQL(sql,values,callback) 
{
  console.log('ExecuteUpdateSQL')
    pool.getConnection().then(conn => {
        conn.query(sql,values)
          .then((res) => {
              conn.end();
              return callback(res);
          })
          .catch(err => {
            console.log(err.message);
            conn.end();
          })
      })
}



return module.exports;