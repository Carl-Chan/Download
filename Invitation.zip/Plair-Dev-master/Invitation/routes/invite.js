
var express = require('express');
var invitedb = require('../includes/invitedb');
var userdb = require('../includes/userdb');
var router = express.Router();

//User Request Invitation Records
//http://localhost:3000/?ref=U0000001
router.get('/', function (req, res) {
  try {
    let uid = req.query.ref; //Current User ID

    if (uid) {
      return DoInviteHistory(uid, res)
    } else {
      return res.json("{'message':'User ID Missing.'")
    }
  } catch (err) {
    console.log(err.message)
    return
  }
});

//Invited User Register Account with Ref ID
//http://localhost:3000/registered/?ref=U0000001&inviteduid=U0000002
router.get('/registered', function (req, res) {
  let uid = req.query.ref; //Current User = Be Invtied User.
  let inviteduid = req.query.inviteduid; // User who invite current user

  if (uid && inviteduid) {
    return DoInvitedUserRegistered(uid, inviteduid, res)
  } else {
    return res.json("{'message':'Missing User Information'")
  }
});

//If Registered User Play the First Game.
//http://localhost:3000/gameplayed/?ref=U0000001
router.get('/gameplayed', function (req, res) {
  let inviteduid = req.query.ref;

  if (inviteduid) {
    return DoInvitedUserGamePlayed(inviteduid, res)
  } else {
    return res.json("{'message':'Invited User Parameter Not Found.'}");
  }
});


//Action to Get User Invitaion Records.
function DoInviteHistory(uid, res) {
  try {
    console.log('Start to Get Invitation Records')
    console.log('Check if User ID exist')
    userdb.IfUserExist(uid, function (result) {
      if (result.length > 0) {
        console.log('User ID Exist and Get Data')
        invitedb.GetInviteRecord(uid, function (result) {
          if (result.length > 0)
            return res.json(result);
          else
            return res.json("{'message':'No Invitation Records'}");
        })
      } else {
        return res.json("{'message':'User not found'}");
      }


    });
  } catch (err) { console.log(err.message); return }
}


//When user register with invite reference id, add new record with inviter user and invited user.
function DoInvitedUserRegistered(uid, inviteduid, res) {
  try {
    var CheckValues = [uid, inviteduid]

    //Check if Both Users are Exist in DB
    userdb.IfBothUserExist(CheckValues, function (IsExist) {
      if (IsExist.length == 2) {
        //Both Users Found in Records.
        invitedb.SetInvitedUserRegistered(uid, inviteduid, function (result) {
          return res.json(result)
        })
      } else {
        return res.json("'message':'User not Exist'")
      }
    })
  } catch (err) {
    console.log(err.message)
    return
  }
}

//When REgistered User Play the First Game, Give Credit to User who invite this user at the most early date 
function DoInvitedUserGamePlayed(inviteduid, res) {
  try {
    console.log('Check If User Exist')
    userdb.IfUserExist(inviteduid, function (result) {
      if (result.length > 0) {
        console.log('User Exist, Go Update the Record')
        invitedb.SetInviteFirstGamed(inviteduid, function (result) {
          if (result.length > 0) {
            return res.json(result)
          } else {
            return res.json("{'message':'No Invite Record Found'}");
          }
        })
      } else {
        console.log('User not exist')
        return res.json("{'message':'User not found'}");
      }
    })
  } catch (err) {
    console.log(err.message)
    return
  }
}
module.exports = router;



